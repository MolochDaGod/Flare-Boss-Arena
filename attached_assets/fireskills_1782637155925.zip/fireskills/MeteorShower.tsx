import { useCallback, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { getFlameTexture, getSpriteTexture } from "@/lib/textures";
import { portalTexture } from "@/lib/fxTextures";
import { GlbModel } from "@/scene/GlbModel";
import { METEOR_URL } from "@/lib/assets";
import { useSandbox, type MeteorShowerSpawn } from "@/store/useSandbox";

const HALF_PI = Math.PI / 2;

// A glowing portal ring hovering above the area that the meteors pour out of.
// Fades in, spins, then fades out as the volley ends.
function MeteorPortal({
  center,
  radius,
  duration,
  color,
}: {
  center: [number, number, number];
  radius: number;
  duration: number;
  color: string;
}) {
  const mesh = useRef<THREE.Mesh>(null);
  const mat = useRef<THREE.MeshBasicMaterial>(null);
  const elapsed = useRef(0);
  const tex = useMemo(() => portalTexture("red"), []);
  const tint = useMemo(() => new THREE.Color(color).multiplyScalar(1.5), [color]);

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.04);
    elapsed.current += dt;
    const e = elapsed.current;
    const fadeIn = Math.min(1, e / 0.3);
    const fadeOut = 1 - Math.min(1, Math.max(0, (e - duration) / 0.8));
    if (mat.current) mat.current.opacity = fadeIn * fadeOut * 0.95;
    if (mesh.current) mesh.current.rotation.z += dt * 0.8;
  });

  return (
    <mesh
      ref={mesh}
      position={[center[0], APEX - 1.5, center[2]]}
      rotation={[HALF_PI, 0, 0]}
      scale={radius * 2.6}
    >
      <planeGeometry args={[1, 1]} />
      <meshBasicMaterial
        ref={mat}
        map={tex}
        color={tint}
        transparent
        opacity={0}
        depthWrite={false}
        side={THREE.DoubleSide}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
}

// AOE meteor shower: a staggered volley of small meteors that streak down over
// an area and detonate as scaled fire explosions (the same FireBurst, shrunk).
const TRAIL = 10;
const APEX = 11; // spawn height above the ground center
const FALL = 0.55; // seconds each meteor takes to fall

interface MeteorData {
  i: number;
  delay: number;
  start: THREE.Vector3;
  target: THREE.Vector3;
  size: number;
}

function FallingMeteor({
  data,
  color,
  onImpact,
}: {
  data: MeteorData;
  color: THREE.Color;
  onImpact: (pos: [number, number, number]) => void;
}) {
  const root = useRef<THREE.Group>(null);
  const trail = useRef<THREE.Points>(null);
  const elapsed = useRef(0);
  const fired = useRef(false);

  const trailPos = useMemo(() => {
    const a = new Float32Array(TRAIL * 3);
    for (let i = 0; i < TRAIL; i++) {
      a[i * 3] = data.start.x;
      a[i * 3 + 1] = data.start.y;
      a[i * 3 + 2] = data.start.z;
    }
    return a;
  }, [data.start]);

  const trailColors = useMemo(() => {
    const c = new Float32Array(TRAIL * 3);
    for (let i = 0; i < TRAIL; i++) {
      const f = (1 - i / TRAIL) * 1.7;
      c[i * 3] = color.r * f;
      c[i * 3 + 1] = color.g * f;
      c[i * 3 + 2] = color.b * f;
    }
    return c;
  }, [color]);

  useFrame((_, delta) => {
    if (fired.current || !root.current) return;
    elapsed.current += Math.min(delta, 0.04);
    const t = (elapsed.current - data.delay) / FALL;
    if (t < 0) {
      root.current.visible = false;
      return;
    }
    root.current.visible = true;
    // Accelerating fall (gravity feel) from start to target.
    const k = Math.min(1, t);
    const e = k * k;
    const pos = root.current.position;
    pos.lerpVectors(data.start, data.target, e);

    if (trail.current) {
      const arr = trail.current.geometry.attributes.position.array as Float32Array;
      for (let i = TRAIL - 1; i > 0; i--) {
        arr[i * 3] = arr[(i - 1) * 3];
        arr[i * 3 + 1] = arr[(i - 1) * 3 + 1];
        arr[i * 3 + 2] = arr[(i - 1) * 3 + 2];
      }
      arr[0] = pos.x;
      arr[1] = pos.y;
      arr[2] = pos.z;
      trail.current.geometry.attributes.position.needsUpdate = true;
    }

    if (t >= 1) {
      fired.current = true;
      root.current.visible = false;
      onImpact([data.target.x, 0.05, data.target.z]);
    }
  });

  return (
    <>
      <group ref={root} position={data.start} visible={false}>
        <GlbModel
          url={METEOR_URL}
          targetLen={data.size * 2.4}
          spin={4}
          fallback={
            <mesh>
              <sphereGeometry args={[data.size, 12, 12]} />
              <meshStandardMaterial
                color={color}
                emissive={color}
                emissiveIntensity={1.4}
                roughness={0.6}
              />
            </mesh>
          }
        />
        <mesh scale={data.size * 1.8}>
          <sphereGeometry args={[1, 12, 12]} />
          <meshBasicMaterial
            map={getSpriteTexture()}
            color={color.clone().multiplyScalar(1.5)}
            transparent
            opacity={0.5}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
          />
        </mesh>
        <pointLight color={color} intensity={5} distance={5} />
      </group>
      <points ref={trail}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[trailPos, 3]} />
          <bufferAttribute attach="attributes-color" args={[trailColors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          map={getFlameTexture()}
          size={data.size * 1.7}
          sizeAttenuation
          vertexColors
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>
    </>
  );
}

function MeteorShower({ spawn }: { spawn: MeteorShowerSpawn }) {
  const remove = useSandbox((s) => s.removeMeteorShower);
  const spawnImpact = useSandbox((s) => s.spawnImpact);
  const elapsed = useRef(0);
  const done = useRef(false);

  const { params, center } = spawn;
  const color = useMemo(() => new THREE.Color(params.color), [params.color]);

  const meteors = useMemo<MeteorData[]>(() => {
    // Shared "wind" so meteors streak in on a consistent diagonal.
    const wx = (Math.random() - 0.5) * 2.5;
    const wz = (Math.random() - 0.5) * 2.5;
    return Array.from({ length: params.count }, (_, i) => {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * params.radius;
      const tx = center[0] + Math.cos(a) * r;
      const tz = center[2] + Math.sin(a) * r;
      return {
        i,
        delay: Math.random() * params.duration,
        start: new THREE.Vector3(tx + wx, APEX + Math.random() * 2, tz + wz),
        target: new THREE.Vector3(tx, 0.05, tz),
        size: 0.26 + Math.random() * 0.12,
      };
    });
  }, [params.count, params.radius, params.duration, center]);

  const onImpact = useCallback(
    (pos: [number, number, number]) => {
      spawnImpact(pos, params.color, false, "fire", params.blastScale);
    },
    [spawnImpact, params.color, params.blastScale],
  );

  useFrame((_, delta) => {
    if (done.current) return;
    elapsed.current += Math.min(delta, 0.05);
    if (elapsed.current > params.duration + FALL + 1.2) {
      done.current = true;
      remove(spawn.id);
    }
  });

  return (
    <group>
      <MeteorPortal
        center={center}
        radius={params.radius}
        duration={params.duration}
        color={params.color}
      />
      {meteors.map((m) => (
        <FallingMeteor key={m.i} data={m} color={color} onImpact={onImpact} />
      ))}
    </group>
  );
}

export function MeteorShowers() {
  const showers = useSandbox((s) => s.meteorShowers);
  return (
    <>
      {showers.map((m) => (
        <MeteorShower key={m.id} spawn={m} />
      ))}
    </>
  );
}
