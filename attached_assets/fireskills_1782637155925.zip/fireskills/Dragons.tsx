import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { GlbModel } from "@/scene/GlbModel";
import { DRAGON_URL } from "@/lib/assets";
import { useSandbox, dummyChest, type DragonSpawn } from "@/store/useSandbox";

const INTRO = 1.1;
const BREATH = 2.5;
const END = 4.0;

function Dragon({ spawn }: { spawn: DragonSpawn }) {
  const remove = useSandbox((s) => s.removeDragon);
  const spawnFlameBolt = useSandbox((s) => s.spawnFlameBolt);
  const spawnImpact = useSandbox((s) => s.spawnImpact);
  const dummyDistance = useSandbox((s) => s.preset.scene.dummyDistance);

  const root = useRef<THREE.Group>(null);
  const done = useRef(false);
  const breathed = useRef(false);
  const elapsed = useRef(0);
  const p = spawn.params;

  const { start, hover } = useMemo(
    () => ({
      start: new THREE.Vector3(2.8, 5.8, 4.8),
      hover: new THREE.Vector3(0, 3.3, 0.4),
    }),
    [],
  );

  useFrame((_, delta) => {
    if (done.current || !root.current) return;
    elapsed.current += delta;
    const e = elapsed.current;

    // Swoop in, then hover with a gentle bob.
    const k = Math.min(1, e / INTRO);
    const ease = 1 - (1 - k) * (1 - k);
    const x = start.x + (hover.x - start.x) * ease;
    const y = start.y + (hover.y - start.y) * ease + Math.sin(e * 2) * 0.12 * k;
    const z = start.z + (hover.z - start.z) * ease;
    root.current.position.set(x, y, z);
    // Face the enemy (sits at x=0, z=-dummyDistance). The dragon GLB's forward
    // axis points back toward +Z, so add a half-turn or it looks away from target.
    root.current.rotation.y = Math.atan2(0 - x, -dummyDistance - z) + Math.PI;

    // Fade in early, fade out over the last 0.5s.
    const fadeIn = Math.min(1, e / 0.4);
    const fadeOut = e > END - 0.5 ? Math.max(0, (END - e) / 0.5) : 1;
    root.current.scale.setScalar(p.scale * fadeIn * fadeOut);

    // Near the end of the animation: breathe a flaming meteor at the enemy.
    if (!breathed.current && e >= BREATH) {
      breathed.current = true;
      const mouth: [number, number, number] = [x, y - 0.2, z - 1.1];
      spawnImpact(mouth, p.color, false, "fire");
      spawnFlameBolt({
        origin: mouth,
        target: dummyChest(dummyDistance),
        size: p.meteorSize,
        color: p.color,
        kind: "meteor",
        burnTime: p.burnTime,
      });
    }

    if (e > END) {
      done.current = true;
      remove(spawn.id);
    }
  });

  return (
    <group ref={root} position={[start.x, start.y, start.z]}>
      <GlbModel
        url={DRAGON_URL}
        targetLen={2.8}
        play
        fallback={
          <mesh>
            <coneGeometry args={[0.5, 1.8, 6]} />
            <meshStandardMaterial
              color={p.color}
              emissive={p.color}
              emissiveIntensity={0.8}
              roughness={0.5}
            />
          </mesh>
        }
      />
      <pointLight color={p.color} intensity={4} distance={9} position={[0, 0, -1]} />
    </group>
  );
}

export function Dragons() {
  const dragons = useSandbox((s) => s.dragons);
  return (
    <>
      {dragons.map((d) => (
        <Dragon key={d.id} spawn={d} />
      ))}
    </>
  );
}
