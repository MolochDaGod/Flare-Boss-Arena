import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { getFlameTexture } from "@/lib/textures";
import type { FireParams } from "@/lib/types";

interface P {
  angle: number;
  baseR: number;
  speed: number;
  life: number;
  age: number;
  seed: number;
}

export function FireAura({
  params,
  active = true,
}: {
  params: FireParams;
  /** When false (e.g. a hidden Gruda slot), skip per-frame buffer work. */
  active?: boolean;
}) {
  const pRef = useRef(params);
  pRef.current = params;
  const core = useRef<THREE.Points>(null);
  const glow = useRef<THREE.Points>(null);
  const count = params.count;

  const { positions, colors, parts } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const parts: P[] = [];
    for (let i = 0; i < count; i++) {
      parts.push({
        angle: Math.random() * Math.PI * 2,
        baseR: 0.2 + Math.random() * 0.8,
        speed: 0.6 + Math.random() * 0.8,
        life: 0.8 + Math.random() * 0.9,
        age: Math.random() * 1.6,
        seed: Math.random() * 100,
      });
    }
    return { positions, colors, parts };
  }, [count]);

  const inner = useMemo(() => new THREE.Color(), []);
  const outer = useMemo(() => new THREE.Color(), []);
  const hot = useMemo(() => new THREE.Color(), []);
  const tmp = useMemo(() => new THREE.Color(), []);
  const white = useMemo(() => new THREE.Color("#ffffff"), []);

  useFrame((state, delta) => {
    if (!active) return;
    if (!core.current || !glow.current) return;
    const p = pRef.current;
    const dt = Math.min(delta, 0.05);
    const t = state.clock.elapsedTime;
    inner.set(p.innerColor);
    outer.set(p.outerColor);
    // White-hot base: the innermost flames glow nearly white before settling to
    // the inner tint, giving the fire a believable temperature gradient.
    hot.copy(inner).lerp(white, 0.6);

    for (let i = 0; i < count; i++) {
      const pt = parts[i];
      pt.age += dt * pt.speed * p.rise;
      if (pt.age > pt.life) pt.age -= pt.life;
      const frac = pt.age / pt.life;

      // Teardrop profile: a wide, slightly bulged base that pinches to a point at
      // the tip, instead of a near-cylindrical column.
      const taper =
        Math.pow(1 - frac, 0.62) * (0.82 + 0.34 * Math.sin(frac * Math.PI));
      // Candle-flame twist: swirl the column upward, plus a per-particle wobble.
      const ang = pt.angle + frac * p.turbulence * 1.15;
      const wobble = Math.sin(t * 3.2 + pt.seed) * p.turbulence * 0.16 * frac;
      const r = pt.baseR * p.radius * taper + wobble;
      // Buoyant rise: accelerate upward as the ember heats and lifts.
      const y = p.height * frac * (0.55 + 0.45 * frac);

      positions[i * 3] =
        Math.cos(ang) * r + Math.sin(t * 5 + pt.seed) * 0.035 * frac;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] =
        Math.sin(ang) * r + Math.cos(t * 5 + pt.seed) * 0.035 * frac;

      // 3-stop ramp: white-hot core → inner tint → outer tint as it cools.
      if (frac < 0.3) tmp.copy(hot).lerp(inner, frac / 0.3);
      else tmp.copy(inner).lerp(outer, (frac - 0.3) / 0.7);
      // Base-weighted falloff with a fast flicker so the flame never looks static.
      const flicker = 0.86 + 0.14 * Math.sin(t * 22 + pt.seed * 3.7);
      const fade = Math.pow(1 - frac, 1.25) * 1.7 * flicker;
      colors[i * 3] = tmp.r * fade;
      colors[i * 3 + 1] = tmp.g * fade;
      colors[i * 3 + 2] = tmp.b * fade;
    }

    // Both layers share the same position/color buffers, so flag both.
    for (const pts of [core.current, glow.current]) {
      const geo = pts.geometry;
      geo.attributes.position.needsUpdate = true;
      geo.attributes.color.needsUpdate = true;
    }
    (core.current.material as THREE.PointsMaterial).size = p.size * 0.92;
    (glow.current.material as THREE.PointsMaterial).size = p.size * 1.5;
  });

  const tex = getFlameTexture();

  return (
    <>
      {/* Opaque flame body — gives the fire real volume instead of flat discs. */}
      <points ref={core} renderOrder={1}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[colors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          map={tex}
          size={params.size * 0.92}
          sizeAttenuation
          transparent
          opacity={0.92}
          depthWrite={false}
          vertexColors
          blending={THREE.NormalBlending}
        />
      </points>
      {/* Additive glow + bloom feed on top. */}
      <points ref={glow} renderOrder={2}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[colors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          map={tex}
          size={params.size * 1.5}
          sizeAttenuation
          transparent
          depthWrite={false}
          vertexColors
          blending={THREE.AdditiveBlending}
        />
      </points>
    </>
  );
}
