import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { getFlameTexture } from "@/lib/textures";
import { useSandbox, type ImpactSpawn } from "@/store/useSandbox";

// A detonation: a tight flash that blooms into an aura burst AND throws off a
// secondary "break-away" spray of fast embers/shards that arc out and fall.
// A `scale` multiplier shrinks the whole thing so the same burst doubles as a
// meteor/blizzard hit or a small stylized spark for UI/hit feedback.
const DURATION = 0.5;

type Kind = NonNullable<ImpactSpawn["kind"]>;

/** Hot core + break-away spark tint per element. */
const PALETTE: Record<Kind, { core: string; spark: string }> = {
  default: { core: "#ffe7a8", spark: "#ffd27a" },
  fire: { core: "#ffe7a8", spark: "#ffb347" },
  ice: { core: "#eaffff", spark: "#bfefff" },
  frost: { core: "#eaffff", spark: "#cdebff" },
  spark: { core: "#ffffff", spark: "#fff1a8" },
  poison: { core: "#eaffb0", spark: "#a3e635" },
};

export function FireBurst({ spawn }: { spawn: ImpactSpawn }) {
  const remove = useSandbox((s) => s.removeImpact);
  const core = useRef<THREE.Points>(null);
  const glow = useRef<THREE.Points>(null);
  const spray = useRef<THREE.Points>(null);
  const flash = useRef<THREE.Mesh>(null);
  const light = useRef<THREE.PointLight>(null);
  const elapsed = useRef(0);
  const done = useRef(false);

  const scl = spawn.scale ?? 1;
  const big = !!spawn.big;
  const reach = (big ? 2.4 : 1.55) * scl;
  const count = big ? 80 : 50;
  const sprayCount = big ? 70 : 46;

  const kind = (spawn.kind ?? "default") as Kind;
  const pal = PALETTE[kind] ?? PALETTE.default;

  const inner = useMemo(
    () => new THREE.Color(pal.core).multiplyScalar(2.3),
    [pal.core],
  );
  const outer = useMemo(
    () => new THREE.Color(spawn.color).multiplyScalar(1.9),
    [spawn.color],
  );
  const sprayHot = useMemo(
    () => new THREE.Color(pal.spark).multiplyScalar(2.6),
    [pal.spark],
  );

  const { positions, colors, parts } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const parts = Array.from({ length: count }, () => {
      // Outward direction biased slightly upward, like a blossoming flame.
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(1 - Math.random() * 1.6); // skew toward horizon→up
      const dir = new THREE.Vector3(
        Math.sin(phi) * Math.cos(theta),
        Math.abs(Math.cos(phi)) * 0.9 + 0.25,
        Math.sin(phi) * Math.sin(theta),
      ).normalize();
      return {
        dir,
        dist: 0.55 + Math.random() * 0.55,
        seed: Math.random() * 100,
      };
    });
    return { positions, colors, parts };
  }, [count]);

  // Break-away spray: each ember launches in a random direction and arcs under
  // gravity, separating from the central bloom.
  const sprayData = useMemo(() => {
    const positions = new Float32Array(sprayCount * 3);
    const colors = new Float32Array(sprayCount * 3);
    const parts = Array.from({ length: sprayCount }, () => {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(1 - Math.random() * 1.5);
      const dir = new THREE.Vector3(
        Math.sin(phi) * Math.cos(theta),
        Math.abs(Math.cos(phi)) * 0.8 + 0.5,
        Math.sin(phi) * Math.sin(theta),
      ).normalize();
      return {
        dir,
        speed: (4.4 + Math.random() * 4.2) * scl,
        life: 0.4 + Math.random() * 0.22,
      };
    });
    return { positions, colors, parts };
  }, [sprayCount, scl]);

  useFrame((state, delta) => {
    if (done.current) return;
    const dt = Math.min(delta, 0.05);
    elapsed.current += dt;
    const k = Math.min(1, elapsed.current / DURATION);
    const ease = 1 - (1 - k) * (1 - k); // easeOutQuad — fast spread, soft settle
    const t = state.clock.elapsedTime;
    const e = elapsed.current;

    // Central bloom.
    for (let i = 0; i < count; i++) {
      const pt = parts[i];
      const r = pt.dist * reach * ease;
      positions[i * 3] = pt.dir.x * r + Math.sin(t * 6 + pt.seed) * 0.04 * scl;
      positions[i * 3 + 1] =
        pt.dir.y * r + ease * 0.25 * scl + Math.cos(t * 5 + pt.seed) * 0.04 * scl;
      positions[i * 3 + 2] = pt.dir.z * r + Math.cos(t * 6 + pt.seed) * 0.04 * scl;

      const mix = Math.min(1, k * 1.4);
      const fade = (1 - k) * 1.7;
      colors[i * 3] = (inner.r + (outer.r - inner.r) * mix) * fade;
      colors[i * 3 + 1] = (inner.g + (outer.g - inner.g) * mix) * fade;
      colors[i * 3 + 2] = (inner.b + (outer.b - inner.b) * mix) * fade;
    }
    for (const pts of [core.current, glow.current]) {
      if (!pts) continue;
      pts.geometry.attributes.position.needsUpdate = true;
      pts.geometry.attributes.color.needsUpdate = true;
    }

    // Break-away spray — ballistic embers that arc out and drop, then fade.
    const sp = sprayData;
    const g = 7.0 * scl;
    for (let i = 0; i < sprayCount; i++) {
      const pt = sp.parts[i];
      const lt = Math.min(e, pt.life);
      sp.positions[i * 3] = pt.dir.x * pt.speed * lt;
      sp.positions[i * 3 + 1] =
        pt.dir.y * pt.speed * lt - 0.5 * g * lt * lt;
      sp.positions[i * 3 + 2] = pt.dir.z * pt.speed * lt;
      const sk = THREE.MathUtils.clamp(e / pt.life, 0, 1);
      const fade = (1 - sk) * 2.0;
      sp.colors[i * 3] = sprayHot.r * fade;
      sp.colors[i * 3 + 1] = sprayHot.g * fade;
      sp.colors[i * 3 + 2] = sprayHot.b * fade;
    }
    if (spray.current) {
      spray.current.geometry.attributes.position.needsUpdate = true;
      spray.current.geometry.attributes.color.needsUpdate = true;
    }

    if (flash.current) {
      const s = ((big ? 0.5 : 0.32) + ease * (big ? 1.3 : 0.8)) * scl;
      flash.current.scale.setScalar(s);
      (flash.current.material as THREE.MeshBasicMaterial).opacity = 1 - k;
    }
    if (light.current) light.current.intensity = (big ? 14 : 9) * (1 - k) * scl;

    if (k >= 1) {
      done.current = true;
      remove(spawn.id);
    }
  });

  const tex = getFlameTexture();

  return (
    <group position={spawn.pos}>
      <mesh ref={flash}>
        <sphereGeometry args={[0.5, 18, 18]} />
        <meshBasicMaterial
          map={tex}
          color={inner}
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>

      {/* Flame body — gives the burst real volume. */}
      <points ref={core} renderOrder={1}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[colors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          map={tex}
          size={(big ? 0.6 : 0.42) * scl}
          sizeAttenuation
          transparent
          opacity={0.92}
          depthWrite={false}
          vertexColors
          blending={THREE.NormalBlending}
        />
      </points>
      {/* Additive glow + bloom feed. */}
      <points ref={glow} renderOrder={2}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[colors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          map={tex}
          size={(big ? 0.98 : 0.68) * scl}
          sizeAttenuation
          transparent
          depthWrite={false}
          vertexColors
          blending={THREE.AdditiveBlending}
        />
      </points>
      {/* Break-away spray — small fast embers/shards flung clear of the bloom. */}
      <points ref={spray} renderOrder={3}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            args={[sprayData.positions, 3]}
          />
          <bufferAttribute
            attach="attributes-color"
            args={[sprayData.colors, 3]}
          />
        </bufferGeometry>
        <pointsMaterial
          map={tex}
          size={(big ? 0.32 : 0.22) * scl}
          sizeAttenuation
          transparent
          depthWrite={false}
          vertexColors
          blending={THREE.AdditiveBlending}
        />
      </points>

      <pointLight
        ref={light}
        color={outer}
        intensity={(big ? 14 : 9) * scl}
        distance={10 * scl}
      />
    </group>
  );
}
