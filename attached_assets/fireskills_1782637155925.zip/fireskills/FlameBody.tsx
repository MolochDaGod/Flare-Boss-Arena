import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { useCharacterSource, cloneCharacter } from "@/lib/character";
import { useSandbox } from "@/store/useSandbox";

// Where the burning twin stands relative to the caster at origin.
const CLONE_OFFSET_X = -2.4;

export function FlameBody() {
  const enabled = useSandbox((s) => s.preset.flameBody.enabled);
  if (!enabled) return null;
  return <FlameClone />;
}

/**
 * A second copy of the caster whose entire body is rendered as living fire: a
 * standard material patched (onBeforeCompile keeps skinning intact) to add a
 * height-based, flickering flame gradient on top of the emissive base.
 */
function FlameClone() {
  const color = useSandbox((s) => s.preset.flameBody.color);
  const source = useCharacterSource();
  const model = useMemo(() => cloneCharacter(source), [source]);
  const mixer = useMemo(() => new THREE.AnimationMixer(model), [model]);
  const uniforms = useRef<Record<string, THREE.IUniform>[]>([]);

  // Swap every mesh's material for a fire-shaded one keyed to its own height.
  // Created materials are tracked and disposed on rebuild/unmount (the cloned
  // geometries are shared with the source, so they are left untouched).
  useEffect(() => {
    uniforms.current = [];
    const created: THREE.Material[] = [];
    const flame = new THREE.Color(color);
    model.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (!mesh.isMesh) return;
      const geo = mesh.geometry as THREE.BufferGeometry;
      geo.computeBoundingBox();
      const bb = geo.boundingBox ?? new THREE.Box3();
      const minY = bb.min.y;
      const maxY = bb.max.y;
      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(0x140402),
        emissive: flame.clone(),
        emissiveIntensity: 1.2,
        roughness: 0.55,
        metalness: 0,
      });
      mat.onBeforeCompile = (shader) => {
        shader.uniforms.uTime = { value: 0 };
        shader.uniforms.uMinY = { value: minY };
        shader.uniforms.uMaxY = { value: maxY };
        shader.uniforms.uFlame = { value: flame.clone() };
        shader.vertexShader =
          "varying float vRawY;\n" +
          shader.vertexShader.replace(
            "#include <begin_vertex>",
            "#include <begin_vertex>\n  vRawY = position.y;",
          );
        shader.fragmentShader =
          "varying float vRawY;\nuniform float uTime;\nuniform float uMinY;\nuniform float uMaxY;\nuniform vec3 uFlame;\n" +
          shader.fragmentShader.replace(
            "#include <dithering_fragment>",
            `
            float h = clamp((vRawY - uMinY) / max(0.001, uMaxY - uMinY), 0.0, 1.0);
            float flick = sin(vRawY * 0.5 + uTime * 9.0)
                        + sin(vRawY * 1.7 - uTime * 5.0) * 0.5;
            flick = flick * 0.25 + 0.5;
            float heat = clamp(1.0 - h + flick * 0.3, 0.0, 1.0);
            vec3 hot = vec3(1.0, 0.95, 0.6);
            vec3 cool = uFlame * 0.4;
            vec3 fire = mix(cool, mix(uFlame, hot, heat), heat);
            gl_FragColor.rgb += fire * (0.5 + 0.9 * heat);
            #include <dithering_fragment>`,
          );
        uniforms.current.push(shader.uniforms);
      };
      mat.needsUpdate = true;
      mesh.material = mat;
      mesh.castShadow = true;
      created.push(mat);
    });
    return () => {
      for (const m of created) m.dispose();
    };
  }, [model, color]);

  // Stand the clone beside the caster and idle in place.
  useEffect(() => {
    model.position.x = CLONE_OFFSET_X;
    const clip = source.neutralIdleClip;
    if (clip) {
      mixer.clipAction(clip).reset().setLoop(THREE.LoopRepeat, Infinity).play();
    }
    return () => {
      mixer.stopAllAction();
    };
  }, [model, mixer, source]);

  useFrame((state, delta) => {
    mixer.update(delta);
    const t = state.clock.elapsedTime;
    for (const u of uniforms.current) {
      if (u.uTime) u.uTime.value = t;
    }
  });

  return <primitive object={model} />;
}
