import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { MeshDistortMaterial } from "@react-three/drei";
import { getFlameTexture } from "@/lib/textures";
import { useSandbox, type ImpactSpawn } from "@/store/useSandbox";

/**
 * Brief deformative shockwave shell. Replaces flat ring "rings/halos" with a
 * roughened, wobbling translucent dome that expands and fades — reads as a
 * heat/force distortion rather than a clean geometric circle.
 */
export function ImpactDistortion({
  color,
  big,
  scale = 1,
}: {
  color: THREE.Color;
  big?: boolean;
  scale?: number;
}) {
  const mesh = useRef<THREE.Mesh>(null);
  const elapsed = useRef(0);
  const DURATION = 0.34;
  const reach = (big ? 2.4 : 1.5) * scale;

  useFrame((_, delta) => {
    if (!mesh.current) return;
    elapsed.current += delta;
    const k = Math.min(1, elapsed.current / DURATION);
    const s = 0.2 + k * reach;
    mesh.current.scale.setScalar(s);
    const mat = mesh.current.material as THREE.Material & { opacity: number };
    mat.opacity = (1 - k) * 0.5;
  });

  return (
    <mesh ref={mesh}>
      <sphereGeometry args={[1, 24, 24]} />
      <MeshDistortMaterial
        color={color}
        emissive={color}
        emissiveIntensity={1.4}
        roughness={1}
        metalness={0}
        transparent
        opacity={0.5}
        depthWrite={false}
        distort={0.6}
        speed={6}
      />
    </mesh>
  );
}

interface Particle {
  vx: number;
  vy: number;
  vz: number;
}

/**
 * The reworked generic impact: ~12 small hot, flame-textured sprites of the
 * impact color that start clustered in a tight sphere then explode outward and
 * fall under gravity. No flat ring + halo — only physical, textured embers.
 */
export function HotBurst({ spawn }: { spawn: ImpactSpawn }) {
  const remove = useSandbox((s) => s.removeImpact);
  const points = useRef<THREE.Points>(null);
  const flash = useRef<THREE.Mesh>(null);
  const elapsed = useRef(0);
  const done = useRef(false);

  const big = !!spawn.big;
  const scale = spawn.scale ?? 1;
  const count = big ? 30 : 22;
  const DURATION = big ? 0.95 : 0.75;
  const GRAVITY = 7.5;

  const color = useMemo(
    () => new THREE.Color(spawn.color).multiplyScalar(1.9),
    [spawn.color],
  );

  const { positions, colors, parts } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const parts: Particle[] = [];
    const tint = new THREE.Color(spawn.color);
    for (let i = 0; i < count; i++) {
      // Start tightly clustered: a little ball before it bursts.
      const r = Math.random() * 0.14 * scale;
      const dir = new THREE.Vector3(
        Math.random() - 0.5,
        Math.random() - 0.5,
        Math.random() - 0.5,
      ).normalize();
      positions[i * 3] = dir.x * r;
      positions[i * 3 + 1] = dir.y * r;
      positions[i * 3 + 2] = dir.z * r;
      // Explode outward; bias slightly upward so embers arc then fall.
      const speed = (3.4 + Math.random() * 3.6) * (big ? 1.4 : 1) * scale;
      parts.push({
        vx: dir.x * speed,
        vy: Math.abs(dir.y) * speed * 0.6 + speed * 0.5,
        vz: dir.z * speed,
      });
      // Vary brightness per ember for a hotter, less uniform look.
      const f = 1.4 + Math.random() * 1.3;
      colors[i * 3] = tint.r * f;
      colors[i * 3 + 1] = tint.g * f;
      colors[i * 3 + 2] = tint.b * f;
    }
    return { positions, colors, parts };
  }, [count, spawn.color, big, scale]);

  useFrame((_, delta) => {
    if (done.current) return;
    const dt = Math.min(delta, 0.04);
    elapsed.current += dt;
    const k = Math.min(1, elapsed.current / DURATION);

    if (points.current) {
      const arr = points.current.geometry.attributes.position
        .array as Float32Array;
      for (let i = 0; i < count; i++) {
        const p = parts[i];
        p.vy -= GRAVITY * dt;
        // Air drag so embers slow as they spread.
        p.vx *= 0.96;
        p.vz *= 0.96;
        arr[i * 3] += p.vx * dt;
        arr[i * 3 + 1] += p.vy * dt;
        arr[i * 3 + 2] += p.vz * dt;
        if (arr[i * 3 + 1] < 0.03) arr[i * 3 + 1] = 0.03;
      }
      points.current.geometry.attributes.position.needsUpdate = true;
      const mat = points.current.material as THREE.PointsMaterial;
      mat.opacity = 1 - k * k;
      mat.size = (big ? 0.64 : 0.46) * scale * (1 + k * 0.4);
    }

    if (flash.current) {
      // Quick central pop: the "sphere" before it bursts apart.
      const fk = Math.min(1, elapsed.current / 0.16);
      const s = (big ? 0.7 : 0.45) * scale * (0.4 + fk * 1.1);
      flash.current.scale.setScalar(s);
      (flash.current.material as THREE.MeshBasicMaterial).opacity =
        (1 - fk) * 0.9;
    }

    if (k >= 1) {
      done.current = true;
      remove(spawn.id);
    }
  });

  return (
    <group position={spawn.pos}>
      <points ref={points}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[colors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          map={getFlameTexture()}
          size={big ? 0.64 : 0.46}
          sizeAttenuation
          vertexColors
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>
      {/* Hot core sphere that flashes then fades as the embers fly out. */}
      <mesh ref={flash}>
        <sphereGeometry args={[0.5, 16, 16]} />
        <meshBasicMaterial
          map={getFlameTexture()}
          color={color}
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
      <ImpactDistortion color={color} big={big} scale={scale} />
      {big && <pointLight color={color} intensity={11} distance={9} />}
    </group>
  );
}
