import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { getSpriteTexture, getFlameTexture } from "@/lib/textures";
import { GlbModel } from "@/scene/GlbModel";
import { METEOR_URL } from "@/lib/assets";
import { useSandbox, type FlameBoltSpawn } from "@/store/useSandbox";

const TRAIL = 18;

function FlameBolt({ spawn }: { spawn: FlameBoltSpawn }) {
  const remove = useSandbox((s) => s.removeFlameBolt);
  const spawnImpact = useSandbox((s) => s.spawnImpact);
  const hitDummy = useSandbox((s) => s.hitDummy);
  const igniteDummy = useSandbox((s) => s.igniteDummy);
  const showDummy = useSandbox((s) => s.preset.scene.showDummy);
  const dummyDistance = useSandbox((s) => s.preset.scene.dummyDistance);
  const dummy = useSandbox((s) => s.preset.layout.dummy);

  const root = useRef<THREE.Group>(null);
  const trail = useRef<THREE.Points>(null);
  const done = useRef(false);
  const elapsed = useRef(0);

  const meteor = spawn.kind === "meteor";
  const color = useMemo(() => new THREE.Color(spawn.color), [spawn.color]);

  const { vel, pos, gravity, flight, trailPos } = useMemo(() => {
    const speed = meteor ? 15 : 13;
    const grav = meteor ? 5 : 6;
    const origin = new THREE.Vector3(...spawn.origin);
    const target = new THREE.Vector3(...spawn.target);
    const horiz = new THREE.Vector3(
      target.x - origin.x,
      0,
      target.z - origin.z,
    ).length();
    const flight = Math.max(0.3, horiz / Math.max(1, speed));
    const gravity = new THREE.Vector3(0, -grav, 0);
    const vel = target
      .clone()
      .sub(origin)
      .divideScalar(flight)
      .sub(gravity.clone().multiplyScalar(0.5 * flight));
    const trailPos = new Float32Array(TRAIL * 3);
    for (let i = 0; i < TRAIL; i++) {
      trailPos[i * 3] = origin.x;
      trailPos[i * 3 + 1] = origin.y;
      trailPos[i * 3 + 2] = origin.z;
    }
    return { vel, pos: origin.clone(), gravity, flight, trailPos };
  }, [spawn, meteor]);

  useFrame((_, delta) => {
    if (done.current || !root.current) return;
    const dt = Math.min(delta, 0.04);
    elapsed.current += dt;

    vel.addScaledVector(gravity, dt);
    pos.addScaledVector(vel, dt);
    root.current.position.copy(pos);

    if (trail.current) {
      const arr = trail.current.geometry.attributes.position
        .array as Float32Array;
      for (let i = TRAIL - 1; i > 0; i--) {
        arr[i * 3] = arr[(i - 1) * 3];
        arr[i * 3 + 1] = arr[(i - 1) * 3 + 1];
        arr[i * 3 + 2] = arr[(i - 1) * 3 + 2];
      }
      arr[0] = pos.x;
      arr[1] = pos.y;
      arr[2] = pos.z;
      trail.current.geometry.attributes.position.needsUpdate = true;
    }

    // Dummy collision: a vertical capsule following the dummy's live layout.
    let hitTheDummy = false;
    if (showDummy && elapsed.current > 0.05) {
      const cx = dummy.posX;
      const cz = -dummyDistance + dummy.posZ;
      const horiz = Math.hypot(pos.x - cx, pos.z - cz);
      const yLo = 0.1 * dummy.scale + dummy.posY;
      const yHi = 2.0 * dummy.scale + dummy.posY;
      if (horiz < 0.6 * dummy.scale && pos.y > yLo && pos.y < yHi)
        hitTheDummy = true;
    }
    const hitGround = pos.y <= 0.08 && elapsed.current > 0.1;
    const expired = elapsed.current > flight * 1.6;

    if (hitTheDummy) {
      done.current = true;
      const dir = vel.clone();
      dir.y = 0;
      if (dir.lengthSq() < 1e-4) dir.set(0, 0, -1);
      dir.normalize();
      spawnImpact([pos.x, pos.y, pos.z], spawn.color, true, "fire");
      hitDummy([dir.x, 0, dir.z], meteor ? 1.3 : 0.7);
      igniteDummy(spawn.burnTime);
      remove(spawn.id);
    } else if (hitGround) {
      done.current = true;
      spawnImpact([pos.x, 0.05, pos.z], spawn.color, meteor, "fire");
      remove(spawn.id);
    } else if (expired) {
      done.current = true;
      remove(spawn.id);
    }
  });

  const trailColors = useMemo(() => {
    const c = new Float32Array(TRAIL * 3);
    for (let i = 0; i < TRAIL; i++) {
      const f = (1 - i / TRAIL) * 1.6;
      c[i * 3] = color.r * f;
      c[i * 3 + 1] = color.g * f;
      c[i * 3 + 2] = color.b * f;
    }
    return c;
  }, [color]);

  return (
    <>
      <group ref={root} position={spawn.origin}>
        {meteor && (
          <GlbModel
            url={METEOR_URL}
            targetLen={spawn.size * 2.4}
            spin={3}
            fallback={
              <mesh>
                <sphereGeometry args={[spawn.size, 16, 16]} />
                <meshStandardMaterial
                  color={color}
                  emissive={color}
                  emissiveIntensity={1.4}
                  roughness={0.6}
                />
              </mesh>
            }
          />
        )}
        {/* hot core */}
        <mesh scale={spawn.size * (meteor ? 0.9 : 1)}>
          <sphereGeometry args={[1, 16, 16]} />
          <meshBasicMaterial
            color={color.clone().lerp(new THREE.Color("#fff6e0"), 0.6).multiplyScalar(2.2)}
            blending={THREE.AdditiveBlending}
            transparent
            depthWrite={false}
          />
        </mesh>
        {/* flame aura shell */}
        <mesh scale={spawn.size * (meteor ? 2.0 : 1.7)}>
          <sphereGeometry args={[1, 16, 16]} />
          <meshBasicMaterial
            map={getSpriteTexture()}
            color={color.clone().multiplyScalar(1.5)}
            transparent
            opacity={0.5}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
          />
        </mesh>
        <pointLight color={color} intensity={meteor ? 7 : 4} distance={6} />
      </group>
      <points ref={trail}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[trailPos, 3]} />
          <bufferAttribute attach="attributes-color" args={[trailColors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          map={getFlameTexture()}
          size={spawn.size * (meteor ? 1.8 : 1.3)}
          sizeAttenuation
          vertexColors
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>
    </>
  );
}

export function FlameBolts() {
  const flameBolts = useSandbox((s) => s.flameBolts);
  return (
    <>
      {flameBolts.map((b) => (
        <FlameBolt key={b.id} spawn={b} />
      ))}
    </>
  );
}
