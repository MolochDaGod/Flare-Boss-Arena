import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { getFlameTexture } from "@/lib/textures";
import { FireAura } from "@/scene/effects/FireAura";
import { muzzle } from "@/lib/muzzle";
import { useSandbox, dummyChest } from "@/store/useSandbox";
import type { FireParams } from "@/lib/types";

type Phase = "idle" | "charge" | "release";

/** Max particles allocated for the jet; the active count is param-driven. */
const MAX = 320;

interface Particle {
  angle: number;
  spread: number;
  life: number;
  age: number;
  speed: number;
}

const _u = new THREE.Vector3();
const _v = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _side = new THREE.Vector3(1, 0, 0);
const _inner = new THREE.Color();
const _outer = new THREE.Color();
const _tmp = new THREE.Color();

/**
 * The fireball cast: charges a compact fire-aura ball in the caster's hand over
 * the length of the cast animation, then releases it forward as a flamethrower
 * jet. Driven entirely by the `muzzle.cast` singleton (bumped by CharacterBody)
 * so it never re-renders per frame.
 */
export function FireCast() {
  const params = useSandbox((s) => s.preset.flameThrow);
  const dummyDistance = useSandbox((s) => s.preset.scene.dummyDistance);
  const showDummy = useSandbox((s) => s.preset.scene.showDummy);

  const pRef = useRef(params);
  pRef.current = params;
  const distRef = useRef(dummyDistance);
  distRef.current = dummyDistance;
  const showRef = useRef(showDummy);
  showRef.current = showDummy;

  const ball = useRef<THREE.Group>(null);
  const jet = useRef<THREE.Points>(null);

  const seen = useRef(muzzle.cast.nonce);
  const phase = useRef<Phase>("idle");
  const t0 = useRef(0);
  const duration = useRef(0.5);
  const didHit = useRef(false);
  const anchor = useMemo(() => new THREE.Vector3(0, 1.2, 0), []);
  const dir = useMemo(() => new THREE.Vector3(0, 0, -1), []);

  // The in-hand charge reads as a compact version of the fire aura, tinted to
  // the flame colors so it visually becomes the jet on release.
  const ballParams = useMemo<FireParams>(
    () => ({
      enabled: true,
      innerColor: params.coreColor,
      outerColor: params.color,
      count: 110,
      size: 0.34,
      height: 0.55,
      rise: 1.3,
      radius: 0.5,
      turbulence: 0.7,
    }),
    [params.coreColor, params.color],
  );

  const { positions, colors, parts } = useMemo(() => {
    const positions = new Float32Array(MAX * 3);
    const colors = new Float32Array(MAX * 3);
    const parts: Particle[] = [];
    for (let i = 0; i < MAX; i++) {
      parts.push({
        angle: Math.random() * Math.PI * 2,
        spread: Math.random(),
        life: 0.35 + Math.random() * 0.45,
        age: Math.random() * 0.8,
        speed: 0.7 + Math.random() * 0.6,
      });
    }
    return { positions, colors, parts };
  }, []);

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.04);
    const now = state.clock.elapsedTime;
    const p = pRef.current;
    const ballG = ball.current;
    const jetP = jet.current;

    // New cast detected → begin charging.
    if (muzzle.cast.nonce !== seen.current) {
      seen.current = muzzle.cast.nonce;
      phase.current = "charge";
      t0.current = now;
      duration.current = Math.max(0.4, muzzle.cast.duration);
      didHit.current = false;
    }

    if (phase.current === "idle") {
      if (ballG) ballG.visible = false;
      if (jetP) jetP.visible = false;
      return;
    }

    // Anchor on the live hand; aim at the dummy chest.
    if (muzzle.handReady) anchor.copy(muzzle.hand);
    const chest = dummyChest(distRef.current);
    dir.set(chest[0] - anchor.x, chest[1] - anchor.y, chest[2] - anchor.z);
    if (dir.lengthSq() < 1e-6) dir.set(0, 0, -1);
    dir.normalize();

    if (phase.current === "charge") {
      // Release the flames a little earlier — fire once the charge reaches most
      // of the way (not the full clip length) so the jet starts sooner.
      const k = Math.min(1, (now - t0.current) / (duration.current * 0.7));
      if (ballG) {
        ballG.visible = true;
        ballG.position.copy(anchor);
        const pulse = 1 + Math.sin(now * 18) * 0.05 * k;
        ballG.scale.setScalar((0.12 + 0.88 * k) * p.chargeSize * pulse);
      }
      if (jetP) jetP.visible = false;
      if (k >= 1) {
        phase.current = "release";
        t0.current = now;
      }
      return;
    }

    // release → flamethrower jet
    const rel = now - t0.current;

    // Ball collapses quickly into the jet.
    if (ballG) {
      const f = Math.max(0, 1 - rel / 0.16);
      ballG.visible = f > 0.02;
      ballG.position.copy(anchor);
      ballG.scale.setScalar(p.chargeSize * f);
    }

    // Land the dummy hit once, at the moment the jet fires.
    if (!didHit.current) {
      didHit.current = true;
      if (showRef.current) {
        useSandbox.getState().hitDummy([dir.x, 0, dir.z], 1.0);
      }
    }

    if (jetP) {
      jetP.visible = true;
      // Orthonormal basis around the aim direction for the cone.
      _u.copy(Math.abs(dir.y) > 0.9 ? _side : _up);
      _u.crossVectors(dir, _u).normalize();
      _v.crossVectors(dir, _u).normalize();
      _inner.set(p.coreColor);
      _outer.set(p.color);

      // Ramp the jet in fast, then fade it out near the end of the burst.
      const env =
        Math.min(1, rel / 0.08) *
        Math.min(1, Math.max(0, (p.burstTime - rel) / 0.3));
      const active = Math.min(MAX, Math.max(0, Math.floor(p.count)));

      for (let i = 0; i < MAX; i++) {
        if (i >= active) {
          colors[i * 3] = 0;
          colors[i * 3 + 1] = 0;
          colors[i * 3 + 2] = 0;
          continue;
        }
        const pt = parts[i];
        // Speed slider scales the cycle rate (7 = the default baseline feel).
        pt.age += dt * pt.speed * (p.speed / 7);
        if (pt.age > pt.life) pt.age -= pt.life;
        const frac = pt.age / pt.life;

        const along = frac * p.range;
        const wob = Math.sin(now * 9 + i) * 0.06 * frac;
        const wid = pt.spread * p.spread * frac + wob;
        const ox = Math.cos(pt.angle) * wid;
        const oy = Math.sin(pt.angle) * wid;

        positions[i * 3] = anchor.x + dir.x * along + _u.x * ox + _v.x * oy;
        positions[i * 3 + 1] = anchor.y + dir.y * along + _u.y * ox + _v.y * oy;
        positions[i * 3 + 2] = anchor.z + dir.z * along + _u.z * ox + _v.z * oy;

        _tmp.copy(_inner).lerp(_outer, Math.min(1, frac * 1.25));
        const fade = (1 - frac) * 1.8 * env;
        colors[i * 3] = _tmp.r * fade;
        colors[i * 3 + 1] = _tmp.g * fade;
        colors[i * 3 + 2] = _tmp.b * fade;
      }

      jetP.geometry.attributes.position.needsUpdate = true;
      jetP.geometry.attributes.color.needsUpdate = true;
    }

    if (rel >= p.burstTime) {
      phase.current = "idle";
      if (jetP) jetP.visible = false;
      if (ballG) ballG.visible = false;
    }
  });

  return (
    <>
      <group ref={ball} visible={false}>
        <FireAura params={ballParams} />
      </group>
      <points ref={jet} visible={false}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[colors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          map={getFlameTexture()}
          size={0.55}
          sizeAttenuation
          vertexColors
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>
    </>
  );
}
