import { useEffect, useRef } from "react";
import * as THREE from "three";
import { FireAura } from "@/scene/effects/FireAura";
import type { FireParams, HotHandsParams } from "@/lib/types";

// Re-parents a mini fire aura under a single hand bone. The Mixamo rig bones
// carry a large (cm-scale) world scale, so we counter it on the group so the
// flame reads at the param's world-unit size regardless of the rig.
function HandFlame({
  bone,
  params,
}: {
  bone: THREE.Object3D;
  params: FireParams;
}) {
  const grp = useRef<THREE.Group>(null);

  useEffect(() => {
    const g = grp.current;
    if (!g) return;
    bone.add(g);
    const scale = new THREE.Vector3();
    bone.getWorldScale(scale);
    g.scale.set(1 / (scale.x || 1), 1 / (scale.y || 1), 1 / (scale.z || 1));
    return () => {
      bone.remove(g);
    };
  }, [bone]);

  return (
    <group ref={grp}>
      <FireAura params={params} />
    </group>
  );
}

export function HotHands({
  bones,
  params,
}: {
  bones: THREE.Object3D[];
  params: HotHandsParams;
}) {
  if (!params.enabled) return null;
  const fire: FireParams = {
    enabled: true,
    innerColor: params.innerColor,
    outerColor: params.outerColor,
    count: params.count,
    size: params.size,
    height: params.height,
    rise: params.rise,
    radius: params.radius,
    turbulence: params.turbulence,
  };
  return (
    <>
      {bones.map((bone, i) => (
        <HandFlame key={bone.uuid ?? i} bone={bone} params={fire} />
      ))}
    </>
  );
}
