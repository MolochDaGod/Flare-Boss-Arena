import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { FireAura } from "@/scene/effects/FireAura";
import { useSandbox } from "@/store/useSandbox";
import type { FireParams } from "@/lib/types";

/**
 * The fire burning at the top of the Cave of Wonders (replaces the model's
 * baked top light). Color + brightness are driven from the store so the user
 * can tune it live. The point light flickers so the cave mouth reads as lit by
 * a real flame.
 */
export function CaveFire() {
  const color = useSandbox((s) => s.preset.scene.caveFireColor);
  const intensity = useSandbox((s) => s.preset.scene.caveFireIntensity);
  const light = useRef<THREE.PointLight>(null);

  // A warm inner core derived from the chosen fire color keeps the flame
  // reading hot at the center regardless of the picked outer hue.
  const inner = useMemo(() => {
    const c = new THREE.Color(color);
    const hsl = { h: 0, s: 0, l: 0 };
    c.getHSL(hsl);
    c.setHSL(hsl.h, Math.max(0, hsl.s - 0.35), Math.min(1, hsl.l + 0.45));
    return `#${c.getHexString()}`;
  }, [color]);

  const fireParams = useMemo<FireParams>(
    () => ({
      enabled: true,
      innerColor: inner,
      outerColor: color,
      count: 320,
      size: 1.1,
      height: 4.2,
      rise: 1.1,
      radius: 1.3,
      turbulence: 0.7,
    }),
    [inner, color],
  );

  useFrame((state) => {
    if (!light.current) return;
    const t = state.clock.elapsedTime;
    const flicker =
      0.82 + Math.sin(t * 17) * 0.08 + Math.sin(t * 6.3 + 1.7) * 0.1;
    light.current.intensity = intensity * flicker;
  });

  return (
    <group>
      <FireAura params={fireParams} />
      <pointLight
        ref={light}
        color={color}
        intensity={intensity}
        distance={45}
        decay={1.4}
      />
    </group>
  );
}
